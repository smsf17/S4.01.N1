package cat.itacademy.barcelonactiva.cognoms.nom.s04.t01.n01.demoS04T01N01SamayoaS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoS04T01N01SamayoaSApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoS04T01N01SamayoaSApplication.class, args);
	}

}
