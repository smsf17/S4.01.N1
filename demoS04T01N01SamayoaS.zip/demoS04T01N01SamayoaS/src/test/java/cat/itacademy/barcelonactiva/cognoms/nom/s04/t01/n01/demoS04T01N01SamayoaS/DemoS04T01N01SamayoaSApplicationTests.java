package cat.itacademy.barcelonactiva.cognoms.nom.s04.t01.n01.demoS04T01N01SamayoaS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoS04T01N01SamayoaSApplicationTests {

	@Test
	void contextLoads() {
	}

}
